﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnVAI.Click
        Form2.Show()
        Me.Hide()
    End Sub
End Class
